#pragma once
#include "Vector2.h"
#include "GameFrame.h"
///////////////////////////////////////////////
//
// UnitŬ����
// Unit�� ����, �ൿ�� ����
// �߻�Ŭ����
//
///////////////////////////////////////////////

#define MAX_UNIT_COUNT 100

typedef enum _UnitState {
	STOP,WATCH, MOVE, ATTACK, COLLISION
}UnitState;

typedef enum _UnitID {
	MARINE, ZERGLING, ULTRA
}UnitID;



class Unit
{
// Static variable 
private:
	static Unit *mpUnitList[MAX_UNIT_COUNT];
	static Unit *mpUnit;
	static int mUnitCount;

// Member variable
protected:
	UnitState mUnitState; // Unit State
	int mUnitSize; // Size be radius
	int mRange; // Unit range must be radius

	VECTOR2 mPos; // Unit Position
	VECTOR2 mDirection; // Unit DirectionVector
	VECTOR2 *mpUnitFocus; // Unit gaze at POINT Ÿ���� ������ ���� ��� and ������ �������� ��� ����
	float mMoveSpeed; // Unit speed == ���⺤�Ϳ� ���� ��

	Unit *mTarget; // Focused target


	

	UnitID mUnitID;
	int mBitmapSize;

	List mRenderList;
	int mhRenderTarget;

// Virtual function
// Should be override
protected:
	virtual void onChangeState() {}
// Member function
protected:
	// check unit range
	void checkRange();


// Interface
public:
	// standard unit process
	void UnitProcess();

	// make parent. get baby
	static bool AddUnit(int i);

	// command
	void Stop();
	void Move();
	void Attack();
	void Focus();

	static void Release();

// Getter, Setter
public:
	inline void SetPos(VECTOR2 mouse) { mPos.x = mouse.x; mPos.y = mouse.y; }
	inline VECTOR2 *GetPos() { return &mPos; }
	inline static Unit** GetUnitList() { return mpUnitList; }
	inline static int GetUnitCount() { return mUnitCount; }
	inline UnitID GetUnitID() { return mUnitID; }

	inline int GetBitmapSize() { return mBitmapSize; }


	void SetState(UnitState state);
	UnitState GetState();
	

// Constructor, Destructor
public:
	Unit();
	~Unit();
};
