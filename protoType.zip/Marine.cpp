#include "Marine.h"
#include "stdafx.h"


const int Marine::TOTAL_IMAGE_COUNT = 229;
const int Marine::UNIT_IMAGE_COUNT = 221;

Marine::Marine()
	:Unit()
{
	mUnitID = MARINE;
	mBitmapSize = 64;
}


Marine::~Marine()
{
}

