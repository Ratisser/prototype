#include "stdafx.h"
#include "Ultra.h"

const int Ultra::TOTAL_IMAGE_COUNT = 265;
const int Ultra::UNIT_IMAGE_COUNT = 255;

Ultra::Ultra()
	:Unit()
{
	mUnitID = ULTRA;
	mBitmapSize = 128;
}


Ultra::~Ultra()
{
}
