#pragma once
#include "Unit.h"


class Zergling :
	public Unit
{
private:
	static const int UNIT_IMAGE_COUNT;
	static const int TOTAL_IMAGE_COUNT;

protected:

public:
	inline static int GetAllImageCount() { return TOTAL_IMAGE_COUNT; }
	inline static int GetUnitImageCount() { return UNIT_IMAGE_COUNT; }

	Zergling();
	~Zergling();
};
