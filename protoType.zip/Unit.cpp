#include "stdafx.h"
#include "Unit.h"

Unit* Unit::mpUnitList[MAX_UNIT_COUNT];
int Unit::mUnitCount = 0;

Unit::Unit() {
	SetPos(Game::GetInstance()->GetMousePoint());
}

Unit::~Unit() {

}

void Unit::UnitProcess() {
	checkRange();
	switch (mUnitState) 
	{
	case STOP:

		break;
	case WATCH:

		break;
	case MOVE:

		break;
	case ATTACK:

		break;
	case COLLISION:

		break;
	}
}

void Unit::checkRange() {

}

bool Unit::AddUnit(int i) {
	if (mUnitCount >= MAX_UNIT_COUNT) {
		return false;
	}
	mUnitCount++;
	switch (i)
	{
	case MARINE:
		mpUnitList[mUnitCount - 1] = new Marine;
		SendMessage(Game::GetInstance()->hList, LB_INSERTSTRING, 0, (LPARAM)L"������ �����߽��ϴ�.");
		break;
	case ZERGLING:
		mpUnitList[mUnitCount - 1] = new Zergling;
		SendMessage(Game::GetInstance()->hList, LB_INSERTSTRING, 0, (LPARAM)L"���۸��� �����߽��ϴ�.");
		break;
	case ULTRA:
		mpUnitList[mUnitCount - 1] = new Ultra;
		SendMessage(Game::GetInstance()->hList, LB_INSERTSTRING, 0, (LPARAM)L"��Ʈ�󸮽�ũ�� �����߽��ϴ�.");
		break;
	}
	return true;
}

void Unit::Move() {
	SetState(MOVE);
	onChangeState();
}

void Unit::SetState(UnitState state) {
	mUnitState = state;
}

void Unit::Release() {
	if (mUnitCount > 0)
	{
		for (int i = 0; i < mUnitCount; i++) {
			delete mpUnitList[i];
		}
	}
}
