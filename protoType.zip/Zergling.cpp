#include "stdafx.h"
#include "Zergling.h"


const int Zergling::TOTAL_IMAGE_COUNT = 296;
const int Zergling::UNIT_IMAGE_COUNT = 289;

Zergling::Zergling()
	:Unit()
{
	mUnitID = ZERGLING;
	mBitmapSize = 128;
	
}


Zergling::~Zergling()
{
}

